a = {'rdbe1':{'info':0, 'rcvd':3}, 'rdbe2':{'info':0, 'rcvd':1}, 'rdbe4':{'info':0, 'rcvd':2}}
b = []
for i in a.keys():
    print "i ", i
    if a[i]['rcvd'] > len(b):
        print "append"
        b.append(i)
    else:
        loc = a[i]['rcvd'] - 1
        print "insert ", loc
        b.insert(loc, i)
    
    print b

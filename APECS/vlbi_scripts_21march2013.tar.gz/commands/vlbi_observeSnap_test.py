
execfile('vlbi_observeSnap.py')

snapfile = 'd21us_c22gl_concat.snp'
vlbi_observeSnap(snapfile)



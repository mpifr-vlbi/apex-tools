import sys
import os

# own library
homepath = os.getenv("HOME")
sys.path.append(homepath + '/commands')
import vlbi_commands

import code
code.interact(local=locals())


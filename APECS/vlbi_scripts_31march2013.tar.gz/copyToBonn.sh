#!/bin/bash

tar czvf vlbi_scripts_31march2013.tar.gz --exclude code_revisions * --exclude *.tar.gz
mv vlbi_scripts_31march2013.tar.gz code_revisions/

#rsync -Laxv ~/* jwagner@portal.mpifr-bonn.mpg.de:/homes/jwagner/apex/apecs/2013/ --exclude 'code_revisions/*.tar.gz'
rsync -Laxv ~/* jwagner@portal.mpifr-bonn.mpg.de:/homes/jwagner/apex/apecs/2013/



while true; do
   scp oper@mark5c1:/home/oper/APEX/GPIB/pollCounters.out .
   cp pollCounters.out 2013-03-gpibcounters.log
   sleep 60
done


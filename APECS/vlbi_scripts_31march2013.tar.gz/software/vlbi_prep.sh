
export FILA10GSA_IP=10.0.2.99
export DBE_IP=10.0.2.101

export FILA_PATH=/home/oper/APEX/FILA10G/
export DBE_PATH=/home/oper/APEX/DBE/dbe/

$FILA_PATH/configureFILA10G.py $FILA10GSA_IP 23

echo -e "selectoutput 3\n\n" | netcat -q 1 -w 1 -u $DBE_IP 10001

$DBE_PATH/dbers232 -u $DBE_IP 10001 -arm
$FILA_PATH/timesyncFILA10G.py $FILA10GSA_IP 23

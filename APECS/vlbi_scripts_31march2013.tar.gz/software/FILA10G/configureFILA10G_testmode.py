#!/usr/bin/python
#
# Python version of FILA10G system setup Windows batch file (*.bat).
#
# Unlike the Windows C++ version, this Python script can handle
# only UDP and TCP links to the FILA10G (RS232<=>IP converters).
#
# Example: ./configureFILA10G.py 10.0.2.99 23
#

import os
import time
import math
import sys
import socket

# Commands to send
_cmds=[]
_cmds.append('\r\nsysstat') # show status
_cmds.append('regwrite regbank0 10 x4170')  # change the station name to "Ap"
_cmds.append('inputselect tvg')             # data source TVG
_cmds.append('tvectmode all-1')             # mode 0x1111
_cmds.append('reset')                       # resync packet stream to 1PPS
_cmds.append('timesync 123 123')            # fake time
_cmds.append('arp off')                     # disable ARP broadcasts from FILA10G
_cmds.append('tengbcfg eth0 mac=ba:dc:af:e4:be:e1')  # change MAC of the FILA10G
_cmds.append('tengbarp eth0 1 01:00:5E:40:20:01')    # add fake non-zero MAC for the gateway ip xx.xx.xx.1
_cmds.append('tengbarp eth0 10 01:00:5E:40:20:01')   # add fake non-zero MAC for UDP destination ip xx.xx.xx.10
_cmds.append('tengbinfo eth0')  # (to verify correct configuration of eth0 10GbE)

# Return a socket:  conn=(ip,port,use_tcp)
def getSocket(conn):
	try:
		if conn['isTCP']:
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((conn['ip'],conn['port']))
		else:
			s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.settimeout(1.0)
		conn['socket'] = s
	except:
		print 'Connection to %s:%u failed' % (conn['ip'],conn['port'])
		return None
	return conn

# Send a command, wait for reply
def sendRcv(conn,cmdstr):
	buffer_size = 2048
	if conn['isTCP']:
		conn['socket'].send(cmdstr)
	else:
		conn['socket'].sendto(cmdstr, (conn['ip'],conn['port']))
	reply = ''
	try:
		while True:
			data = conn['socket'].recv(buffer_size)
			reply = reply + data
	except:
		print 'Reply: %s' % (reply.strip())
		# print 'Timed out with no reply'

# Infos
def usage_exit():
	print 'Usage: timesyncFILA10G.py [-u|--udp] <ip_address> <ip_port>'
	sys.exit(-1)

# Prepare and send commands to FILA10G
def main(argv):
	global _cmds

	if len(argv)<3:
		usage_exit()

	if (argv[1][0]=='-'):
		if (argv[1]=='--udp' or argv[1]=='-u') and len(argv)==4:
			conn_TCP = False
			conn_IPaddr = str(argv[2])
			conn_IPport = int(argv[3])	
		else:
			usage_exit()
	else:
		conn_TCP = True
		conn_IPaddr = str(argv[1])
		conn_IPport = int(argv[2])
	conn = {'ip':conn_IPaddr, 'port':conn_IPport, 'isTCP':conn_TCP, 'socket':None}

	print 'Connecting...'
	conn = getSocket(conn)
	if (conn==None):
		sys.exit(-1)

	print 'The following commands will be sent:'
	for cmd in _cmds:
		print 'Command: ', cmd.strip()
	for cmd in _cmds:
		sendRcv(conn, cmd+'\r\n')

	print 'Done!'

if __name__ == "__main__":
    main(sys.argv)


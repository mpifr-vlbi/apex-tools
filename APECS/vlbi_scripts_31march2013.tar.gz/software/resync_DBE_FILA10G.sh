#!/bin/bash

DBE_IP=134.104.25.130
FILA10G_IP=134.104.25.21

echo "------ DBE 1PPS SYNC ------"
echo "./DBE/dbe/dbers232 -u $DBE_IP 10001 -arm"
./DBE/dbe/dbers232 -u $DBE_IP 10001 -arm

sleep 3

echo "------ FILA10G select DBE VSI0 as input ------"
echo "./FILA10G/configureFILA10G.py $FILA10G_IP 23"
./FILA10G/configureFILA10G.py $FILA10G_IP 23

sleep 3

echo "------ FILA10G sync clock to VSI 1PPS ------"
echo "./FILA10G/timesyncFILA10G.py $FILA10G_IP 23"
./FILA10G/timesyncFILA10G.py $FILA10G_IP 23

sleep 3

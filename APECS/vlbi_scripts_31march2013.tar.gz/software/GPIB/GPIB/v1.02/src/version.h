#ifndef VERSION_H
#define VERSION_H

#define SOFTWARE_VERSION "1.02"

#endif

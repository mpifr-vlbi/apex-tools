#!/bin/bash

# usage: pingVectorVoltmeter <IPaddress> <port> <number of measurements> <sample period / s>

../bin/pingVectorVoltmeter 10.0.2.93 1234 200 1

#ifndef NETTOOLS_H
#define NETTOOLS_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>

void err(const char *, ...);
int tcp_client(const char *servIP, const char *servPort);
void sendMessage(int sockfd, char *buff);
void readMessage(int sockfd, char *buff, size_t maxlen);

#endif

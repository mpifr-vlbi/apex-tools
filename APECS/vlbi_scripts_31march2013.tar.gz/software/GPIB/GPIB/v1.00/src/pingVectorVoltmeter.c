/* ALR 23.09.10
 * based on ~/EB/1mm/APEX/DownconverterComms/pingCounters.c
 *
 * Client that talks to HP 8508A vector voltmeter
 *  uses TCP socket to talk to Prologix media converter at port 1234
 *
 * Based on example code by Richard Stevens 1998, p295
 *  "UNIX Network Programming: Networking APIs: Sockets and XTI" Prentice Hall
 *  http://www.kohala.com/start/
 *
 * Compile with:  'gcc -Wall -O0 pingVectorVoltmeter.c -o pollVectorVoltmeter'
 *
 */

#include "nettools.h"

#define MAXLINE 4096          /* max text line length */
#define OUTFILE "pingVectorVoltmeter.out"

#define _PRINT 1

int main(int argc, char **argv) {
  int sockfd;
  char recvline[MAXLINE + 1];
  //int errn;
  //socklen_t salen;
  //struct sockaddr *sa;
  char buff[MAXLINE];
  int i, n, nMeasurements, samplePeriod;
  FILE *fp;
  float amp, phase;
  time_t timerStart, timerNow;
  double elapsedTime;

/* Print a helpful message if the number of command line arguments is wrong */

  if (argc != 5)
    err("usage: pingVectorVoltmeter <IPaddress> <port> <number of measurements> <sample period / s>");

  if (_PRINT == 1)
    printf("\n*** pingVectorVoltmeter ***\n\n");


/* Create a TCP socket */

  sockfd = tcp_client(argv[1], argv[2]);
  if (sockfd < 0) {
    snprintf(buff, sizeof(buff), "socket error: %s", strerror(errno));
    err(buff);
  }


/* Configure GPIB controller with device address of the vector voltmeter */

  sendMessage(sockfd, "++addr 8\n");


/* Query the GPIB controller to confirm device address setting */

  sendMessage(sockfd, "++addr\n");
  readMessage(sockfd, recvline, MAXLINE);


/* Query the vector voltmeter identification */

  sendMessage(sockfd, "*IDN?\n");
  readMessage(sockfd, recvline, MAXLINE);


/* Configure the vector voltmeter */

  sendMessage(sockfd, "TRIGGER:SOURCE FREE\n");
  sendMessage(sockfd, "FORMAT LIN\n");
  sendMessage(sockfd, "SENSE TRANSMISSION\n");


/* Check for errors */

  sendMessage(sockfd, "SYSTEM:ERR?\n");
  readMessage(sockfd, recvline, MAXLINE);
  if (recvline[0]!='0') {
    // zero character ("0,NO ERROR") means everything is ok
    // non-zero is an error ("-110,CMD HEADER ERROR, ...")
    printf("Request 'SYSTEM:ERR?' reply was '%s', error?\n", recvline);
  }

/* Make measurements */

  nMeasurements = atoi(argv[3]);

  samplePeriod = atoi(argv[4]);

  fp = fopen(OUTFILE, "w");
  if (fp == NULL) {
    printf("Trouble opening output file %s\n", OUTFILE);
    exit(1);
  }

  fprintf(fp, "--------------------------------\n");
  fprintf(fp, "Elapsed      Amp         Phase\n");
  fprintf(fp, "Time / s     / V         / deg\n");
  fprintf(fp, "--------------------------------\n");
  if (_PRINT) {
    printf("--------------------------------\n");
    printf("Elapsed      Amp         Phase\n");
    printf("Time / s     / V         / deg\n");
    printf("--------------------------------\n");
  }

  time(&timerStart);
  for (i = 1; i <= nMeasurements; i++) {
    if (_PRINT == 1)
      printf("\nMeasurement %d of %d\n", i, nMeasurements);
    /*    sendMessage(sockfd, "*TRG\n"); */
    sendMessage(sockfd, "FETCH?\n");
    readMessage(sockfd, recvline, MAXLINE);
    sscanf(recvline, "%f,%f", &amp, &phase);
  
    time(&timerNow);
    elapsedTime = difftime(timerNow, timerStart);
    fprintf(fp, "%.0lf        %10.3e   %10.3e\n", elapsedTime, amp, phase);
    if (_PRINT)
      printf("%.0lf        %10.3e   %10.3e\n", elapsedTime, amp, phase);
    fflush(fp);
    sleep(samplePeriod);
  }


/* Normal completion */

  close(sockfd);
  fclose(fp);
  exit(0);
}

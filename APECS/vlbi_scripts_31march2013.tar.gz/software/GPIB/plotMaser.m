
function plotMaser(fname,fields)

d=load(fname,'ascii');

day=d(:,1); 
month=d(:,2);
year=d(:,3);
hour=d(:,4);
minute=d(:,5);
second=d(:,6);
data=d(:,7:end);
headers={'U batt.A[V]', 'I batt.A[A]', 'U batt.B[V]', 'I batt.B[A]', ...   % 1..4
    'Set H[V]', 'Meas. H[V]', 'I pur.[A]', 'I diss.[A]', 'H light[V]', ... % 5..9
    'IT heater[V]', 'IB heater[V]', 'IS heater[V]', 'UTC heater[V]', ...   % 10..13
    'ES heater[V]', 'EB heater[V]', 'I heater[V]', 'T heater[V]', ...      % 14..17
    'Boxes temp[degC]', 'I boxes[A]', 'Amb.temp.[degC]', 'C field[V]', ... % 18..21
    'U varactor[V]', 'U HT ext.[kV]', 'I HT ext[uA]', 'U HT int.[kV]', ... % 22..25
    'I HT int.[uA]', 'H st.pres.[bar]', 'H st. heat[V]', 'Pirani heat.[V]', ...
    'Unused', 'U 405kHz[V]', 'U OCXO[V]', '+24 VDC[V]', '+15 VDC[V]', ...
    '-15 VDC[V]', '+5 VDC[V]', '-5 VDC[V]', '+8 VDC[V]', '+18 VDC[V]', ...
    'Unused', 'Lock', 'DDS'};
%plotcolors = { 'r','g','b', 'r-.','g-.','b-.', 'r.','g.','b.'};
plotcolors = { 'r.','g.','b.', 'rx','gx','bx'};
    
T = (day - day(1))*(24*60*60) + hour*60*60 + minute*60 + second;
T = T + (month - month(1))*31*(24*60*60);
data=data(:,fields);

figure(1),clf,
hold on;
for ff=1:max(size(fields)),
    colorstr = char(plotcolors(ff));
    plot(T,data(:,ff), colorstr);
end
xlabel('Time [s]');
legend(headers(fields));

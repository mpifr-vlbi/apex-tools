% Opens file 'fname', plots the last 'Npoints' points of data fields 
% given by indices specified in vector 'fields'. Keeps running
% and polling the input file for new data points. Updates the plot
% as the contents of the 'fname' file is growing.
%
% The input file _must_ be the raw format input with time in 
% the format "dd/mm/yyyy" instead of "dd mm yyyy".
%
% Argument 'scaleYmax' is optional, defaults to 60.
%
function tailMaser(fname,fields,Npoints,scaleYmax)

use_reopen = true; % try reopening method

eval('scaleYmax', 'scaleYmax=60'); % default to 60
plotcolors = { 'r.','g.','b.', 'rx','gx','bx', 'ro','go','bo',};
headers={'U batt.A[V]', 'I batt.A[A]', 'U batt.B[V]', 'I batt.B[A]', ...   % 1..4
    'Set H[V]', 'Meas. H[V]', 'I pur.[A]', 'I diss.[A]', 'H light[V]', ... % 5..9
    'IT heater[V]', 'IB heater[V]', 'IS heater[V]', 'UTC heater[V]', ...   % 10..13
    'ES heater[V]', 'EB heater[V]', 'I heater[V]', 'T heater[V]', ...      % 14..17
    'Boxes temp[degC]', 'I boxes[A]', 'Amb.temp.[degC]', 'C field[V]', ... % 18..21
    'U varactor[V]', 'U HT ext.[kV]', 'I HT ext[uA]', 'U HT int.[kV]', ... % 22..25
    'I HT int.[uA]', 'H st.pres.[bar]', 'H st. heat[V]', 'Pirani heat.[V]', ...
    'Unused', 'U 405kHz[V]', 'U OCXO[V]', '+24 VDC[V]', '+15 VDC[V]', ...
    '-15 VDC[V]', '+5 VDC[V]', '-5 VDC[V]', '+8 VDC[V]', '+18 VDC[V]', ...
    'Unused', 'Lock', 'DDS'};

Nfields = max(size(headers));
data = zeros(Npoints,Nfields);
datatime = zeros(Npoints,1);
Npointsvalid = 0;

while 1,
   fd = fopen(fname, 'rt'); % read,text
   if (fd>=0),
       break;
   end
   pause(0.5);
end
str = fgetl(fd); % discard header line
Nlines = 0;

while 1,
    
   % re-open the file robustly?
   if use_reopen,
       fclose(fd);
       while 1,
           fd = fopen(fname, 'rt'); % read,text
           if (fd>=0),
               break;
           end
           pause(0.5);
       end
       str = fgetl(fd); % discard header line
       for ii=1:Nlines,
           str = fgetl(fd); % hop over previous lines
       end
   end
   
   % get new data line
   str = fgetl(fd);
   if not(ischar(str)) || (max(size(str))<=1),
       fprintf(1, 'No new data, pausing\n');
       pause(0.5);
       continue;
   end
   fprintf(1, 'Read: %s\n', str);
   Nlines = Nlines + 1;

   % Test case:
   if 0,
      fprintf(1, 'Unit Test mode!!\n')
      str='30/04/2012 12:29:20	27.808	0.127	28.345	2.809	5.046	2.020	0.621	0.422	3.734	12.930	10.918	10.078	11.221	8.408	8.701	5.376	7.041	44.897	0.184	23.108	5.476	8.516	3.525	6.348	3.535	4.395	6.475	12.091	9.985	0.000	0.000	0.000	24.80	14.45	-15.39	5.04	0.00	7.93	17.11	0.00	0.00	1420405750.305628';
      str='20/04/12 00:27:11	27.93	0.068	28.442	2.181	0.187	0.027	0.402	0.02	0.062	13.003	11.47	9.551	11.88	9.487	10.259	6.011	7.9	    44.873	0.229	23.816	5.471	8.513	3.523	5.493	3.535	3.418	3.604	0.11	0.122	0	0	0	24.9	14.53	-15.39	5.04	0	7.97	17.19	0	0	1420405750.305628';
   end
   tstr = str(1:20);
   dstr = str(21:end);

   % Extract time from first columns
   td = sscanf(tstr, '%d/%d/%d %d:%d:%d'); % dd/mm/yyyy hh:mm:ss
   td = double(td);
   %tpoint = (td(1) + 30.0*td(2))*24*60*60.0 + td(4)*60*60.0 + td(5)*60.0 + td(6);
   tpoint = td(4)*60.0*60.0 + td(5)*60.0 + td(6);
   Npointsvalid = min([Npointsvalid+1, Npoints]);
   
   % Extract data from remaining columns
   Ncols = sum(dstr=='.'); % fails on current prog where 0.000 logged as 0
   if (Ncols ~= Nfields),
       %fprintf(1, 'Log entry should have %d data columns, found %d instead!\n', Nfields, Ncols);
   end
   fmt = repmat('%f ', [1 Nfields]); % was:Ncols
   dpoint = sscanf(dstr, fmt);
   
   % Append data point
   datatime(1:(end-1),1) = datatime(2:end,1);
   datatime(end,1) = tpoint;
   data(1:(end-1),:) = data(2:end,:);
   data(end,:) = dpoint;

   % Update the plot
   figure(1),clf,
   hold on;
   xx = datatime((end-Npointsvalid+1):end);
   for ff=1:max(size(fields)),
      colorstr = char(plotcolors(ff));
      yy = data((end-Npointsvalid+1):end, fields(ff));
      plot(xx,yy, colorstr);
      ax = axis(); axis([ax(1) ax(2) 0 scaleYmax]);
   end
   xlabel('Time [s]');
   tstr = sprintf('Nlines=%d', Nlines)
   title(tstr);
   legend(headers(fields), 'Location','NorthEastOutside');

end

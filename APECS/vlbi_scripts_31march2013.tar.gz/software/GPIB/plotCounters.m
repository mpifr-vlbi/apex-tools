
function plotCounters(fname)

d=load(fname,'ascii');
T=d(:,1);
rate=d(:,2);
dT=median(T(2:end)-T(1:(end-1)));

ddT=(T(2:end)-T(1:(end-1)));
glitches=(ddT~=dT);

rate = rate(2:end) ./ dT;
T = T(2:end);

p = polyfit(T,rate,1);
rate_fit = polyval(p,T);
rate_residual = rate - rate_fit;
fit_str = sprintf('Fit y=%e*t + %e', p(1), p(2));
fprintf(1, '%s\n', fit_str);

figure(1),clf,

subplot(2,1,1),
plot(T,rate), grid on,
xlabel('Time [s]'), ylabel('1PPS[1]-1PPS[2] at 10 MHz'),
title('1PPS offset in sec/1sec');

subplot(2,1,2),
plot(T,rate_residual), grid on,
xlabel('Time [s]'), ylabel('1PPS[1]-1PPS[2] at 10 MHz'),
fit_title = sprintf('%s residual in sec/sec', fit_str);
title(fit_title);

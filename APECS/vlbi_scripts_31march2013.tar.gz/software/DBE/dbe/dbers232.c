#include <sys/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>           /* for socket close() */
#include <linux/sockios.h>

#define MAXLINE 4096
#define base 0x3f8              // com1 0x3f8 com2 0x2f8
#define nwait 20000
// #define nscope 512
#define nscope 256

void sendSerial(char *,char *,int *,int);
void sendUDP(char *,char *,int *,int);
void sendCommand(char *,char *,int *,int);
void err(const char *fmt, ...);
int udp_client(const char *host, const char *serv, void **saptr, socklen_t *lenp);

int useUDP = 0;
int sockfd;
socklen_t salen;
struct sockaddr *sa;
unsigned char ipaddress[17];
unsigned char port[7];

int main (int argc, char *argv[])
{
    int kk,i,k,j,gain,gn,gfile,read,file,hlp,arm,pow,listdev;
    int pw[2048];
    double amp;
    unsigned char m[MAXLINE],recvbuff[20*MAXLINE],buf[80],filenam[80];
    FILE *file1;
    struct timeval tv;
    unsigned char buff[MAXLINE];

    
    if (argc < 2)
    {
        printf("dbers232 -g gain - to set gain\n");
        printf("dbers232 -sgfile0 - to set gains to pol0 from RJCs file\n");
        printf("dbers232 -sgfile1 - to set gains to pol1 from RJCs file\n");
        printf("dbers232 -f filename - to execute commands from file\n");
        printf("dbers232 -r - to read gains\n");
        printf("dbers232 -arm - arm1pps\n");
        printf("dbers232 -pow - to check power levels from real\n");
        printf("dbers232 -pinterp - to check power levels from interp\n");
        printf("dbers232 -h - to get IBOB help\n");
        printf("dbers232 -listdev - to list devices\n");
        printf("dbers232 -u ipaddress port - use UDP xport connection instead of serial\n");
        return;
    }
    gain=500;
    read=file=hlp=arm=pow=gn=listdev=gfile=0;
    for(i=0; i<argc; i++)
    {
        sscanf(argv[i], "%79s", buf);
        if (strstr(buf, "-g"))
        {
            sscanf(argv[i+1], "%d",&gain);
            gn=1;
        }
        if (strstr(buf, "-r")) read=1;
        if (strstr(buf, "-h")) hlp=1;
        if (strstr(buf, "-arm")) arm=1;
        if (strstr(buf, "-pow")) pow=1;
        if (strstr(buf, "-pinterp")) pow=2;
        if (strstr(buf, "-listdev")) listdev=1;
        if (strstr(buf, "-f"))
        {
            sscanf(argv[i+1], "%79s",filenam);
            file=1;
        }
        if (strstr(buf, "-sgfile0"))
        {
            sscanf(argv[i+1], "%79s",filenam);
            gfile=1;
        }
        if (strstr(buf, "-sgfile1"))
        {
            sscanf(argv[i+1], "%79s",filenam);
            gfile=2;
        }
	if  (strstr(buf, "-u"))
        {
	    if (argc <= i + 2)
	    {
		fprintf (stderr, "-u option requires ipaddress and port as parameters\n");
		return(1);
	    }
            sscanf(argv[i+1], "%s", ipaddress);
            sscanf(argv[i+2], "%s", port);
            useUDP = 1;
        }

	
    }
//  if(read) printf("reading only\n");
    if(file || gfile)
    {
        if((file1=fopen(filenam,"r"))==NULL) return 0;
    }

    if (useUDP)
    {
	  //Create a UDP socket 
	  sockfd = udp_client(ipaddress, port, (void **) &sa, &salen);
	  if (sockfd < 0) {
	    snprintf(buff, sizeof(buff), "socket error: %s", strerror(errno));
	    err(buff);
	  }

	  // Set 30 s timeout for socket read operations

	  tv.tv_sec = 1;
	  tv.tv_usec = 0;
	  setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    }
    else
    {
	    if(ioperm(base,8,1))
	    {
		printf("ioperm failed\n");
		return 0;
	    }
	    outb (128 + 3, base + 3);
	    outb (0x01, base);
	    outb (0, base + 1);         // 115,200 8 data 1 stop noparity
	    outb (3, base + 3);         // LCR   8 data 1 stop
	    outb (7, base + 1);
	    outb (1, base + 2);         // IIR
	    outb (3, base + 4);         // MCR
	//      outb (0xC7, base + 2);       // IIR
	    kk = 0;
	    while ((inb (base + 2) & 1) == 0 && kk < nwait)
	    {
		inb (base);
		kk++;
	    }
    }

    m[0] = '\r';
    m[1] =0;
    sendCommand(m, recvbuff, pw, 0);
    if(strstr(recvbuff,"IBOB") == 0)
    {
        printf("no prompt\n");
        return 0;
    }

    sprintf(m,"selectoutput 3\r");          // for new firmware
    sendCommand(m,recvbuff,pw,0);
    sendCommand(m,recvbuff,pw,0);
    if(gn || read)
    {
        for(j=0; j<2; j++)
        {
            for(i=0; i<8; i++)
            {
                for(k=0; k<2; k++)
                {
                    if(read) sprintf(m,"bramread pol%d/gainctrl%d %d\r",j,k,i);
                    else sprintf(m,"bramwrite pol%d/gainctrl%d %d %d\r",j,k,i,gain);
                    sendCommand(m,recvbuff,pw,0);
                }
            }
        }
        if(read) sprintf(m,"regread shiftctrl_reg\r");
        else sprintf(m,"regwrite shiftctrl_reg x3F\r");
        sendCommand(m,recvbuff,pw,0);
        if(!read)
        {
            sprintf(m,"selectoutput 3\r");
            sendCommand(m,recvbuff,pw,0);
        }
    }
    if(file)
    {
        while(fgets(m,256,file1) != 0)
        {
            sendCommand(m,recvbuff,pw,0);
        }
        fclose(file1);
    }
    if(gfile)        //  needs update
    {
        FILE* fdnewgains = fopen("gains.log","w");
        while(fgets(m,256,file1) != 0)
        {
            j=-999;
            sscanf(m,"%d %*s %*s %*s %*s %*s %*s %*s %*s %lf",&j,&amp);
		  printf("%s",m);
//        j = 15 - j;   Mark 5 reverses order
            if(j>=0 && j<16)
            {
                if(gfile==1)
                {
                    sprintf(m,"bramread pol0/gainctrl%d %d\r",(j%2),j/2);
                    sendCommand(m,recvbuff,pw,0);
//          printf("\nrecvbuffd test %s\n",recvbuff);
                    sscanf(recvbuff,"%*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %d",&gain);
                    //char buff[1024], b1[1024];
                    //sscanf(recvbuff,"%*s %*s %*s %*s %*s %*s %*s %*s %s %s",buff, b1);
                    //printf ("buff: %s %s\n", buff, b1);
                    printf("read gain = %d ratio = %5.2f setting new gain = %d\n",gain,amp,(int)(amp*gain));
                    sprintf(buf,"bramwrite pol0/gainctrl%d %d %d\r",(j%2),j/2,(int)(amp*gain));
                    fprintf(fdnewgains, "%d\t %d\t %d\n", j, gain, (int)(amp*gain));
                }
                if(gfile==2)
                {
                    sprintf(m,"bramread pol1/gainctrl%d %d\r",(j%2),j/2);
                    sendCommand(m,recvbuff,pw,0);
                    sscanf(recvbuff,"%*s %*s %*s %*s %*s %*s %*s %*s %d",&gain);
                    printf("read gain = %d ratio = %5.2f setting new gain = %d\n",gain,amp,(int)(amp*gain));
                    sprintf(buf,"bramwrite pol1/gainctrl%d %d %d\r",(j%2),j/2,(int)(amp*gain));
                    fprintf(fdnewgains, "%d\t %d\t %d", j, gain, (int)(amp*gain));
                }
                sendCommand(buf,recvbuff,pw,0);
            }
        }
        fclose(file1);
        fclose(fdnewgains);
    }
    if(hlp)
    {
        sprintf(m,"?\r");
        sendCommand(m,recvbuff,pw,1);
    }
    if(arm)
    {
        sprintf(m,"arm1pps\r");
        sendCommand(m,recvbuff,pw,0);
    }
    if(listdev)
    {
        sprintf(m,"listdev\r");
        sendCommand(m,recvbuff,pw,1);
    }

    if(pow)    // -pow or -pinterp options
    {
        for(i=0; i<nscope; i++) pw[i+nscope] = 0;
        if(pow==1) // -pow option
        {
            sprintf(m,"scopeenable pol0/scopes3/real 0\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopereset pol0/scopes3/real\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopedelay pol0/scopes3/real 0\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopeenable pol0/scopes3/real 1\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopestatus pol0/scopes3/real\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(2);
            while(strstr(recvbuff,"Scope has not been triggered"))
            {
                sendCommand(m,recvbuff,pw,0);
                sleep(1);
            }
	
            sprintf(m,"scoperead pol0/scopes3/real %3d\r",nscope);
            sendCommand(m,recvbuff,pw,2);
            sleep(1);
        }
        if(pow==2) // -pinterp option
        {
            sprintf(m,"scopeenable pol0/scopes3/interp 0\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopereset pol0/scopes3/interp\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopedelay pol0/scopes3/interp 0\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopeenable pol0/scopes3/interp 1\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(3);
            sprintf(m,"scopestatus pol0/scopes3/real\r");
            sendCommand(m,recvbuff,pw,0);
            sleep(2);
            while(strstr(recvbuff,"Scope has not been triggered"))
            {
                sendCommand(m,recvbuff,pw,0);
                sleep(1);
            }
            sprintf(m,"scoperead pol0/scopes3/interp %3d\r",nscope);
            sendCommand(m,recvbuff,pw,2);
            sleep(1);
        }
        for(i=1; i<9; i++)
        {
            k  =0;
            amp=0;
            for(j=i; j<nscope; j+=8)
            {
                if(pw[j+nscope])
                {
                    amp += (double)pw[j]*(double)pw[j];
                    k++;
                }
            }
            printf("chan %2d amp %8.3e\n",-2+i*2,amp/(double)k);
        }
    }
    sleep(1);
    m[0] = '\r';
    m[1] =0;
    sendCommand(m,recvbuff,pw,0);
    if(strstr (recvbuff,"IBOB") == 0)
    {
        printf("no prompt\n");
        return 0;
    }
}

void sendCommand (char m[],char recvbuff[],int pw[],int mode)
{

	if (useUDP)
	{
		sendUDP(m, recvbuff, pw, mode);
	}
	else
	{
		sendSerial(m, recvbuff, pw, mode);
	}

}

void sendUDP (char m[],char recvbuff[],int pw[],int mode)
{
 	int n = 0;
        unsigned int amp;
	int j;
	char readBuff[20*MAXLINE];
	char tempBuff[MAXLINE];


	printf("Sending: %s\n", m);
	sendto(sockfd, m, strlen(m), 0, sa, salen);

	memset (readBuff, '\0', 20*MAXLINE);
	if (mode == 2)  // read power
	{
		//datagrams can become larger than MTU and will be split up	
		while ((n = recv(sockfd, tempBuff, MAXLINE, 0)) > 0)
		{
			strcat (readBuff, tempBuff);
		//	printf ("Received: %d %s\n", n, recvbuff);
			memset (tempBuff, '\0', MAXLINE);
		}
	}
	else
	{
		n = recvfrom(sockfd, readBuff, MAXLINE, 0, NULL, NULL);
	}

	//printf ("Final: %d %s\n", n, readBuff);

	if (mode ==2)
	{
		char * pch;

		pch = strtok (readBuff,"\r\n");
		while (pch != NULL)
		{
			//printf ("line: %s\n", pch);

			int jj = sscanf(pch,"%*s %*s %d %*s %x",&j,&amp);

			//printf ("parse: %d %d %d\n", jj, j, amp);
			if(j<nscope && j >=0 && jj==2)
			{
			    //pw[j] =(amp>>16)<<16;
			    pw[j] =amp;
			    pw[j+nscope] = 1;       // mark data as recvbuffd
			    printf("%3d power %12d\n",j,pw[j]);
			}
			pch = strtok (NULL, "\r\n");
			if (strstr(pch, "/") == NULL)
				break;
		}
	}
	else
		 printf ("Received: %d %s\n", n, readBuff);


	strcpy(recvbuff, readBuff);
}

void sendSerial(char m[],char recvbuff[],int pw[],int mode)
{
    int n,kk,i,j,jj,mm,iwait;
    unsigned int amp;
    char chh;
//             printf("sending ");
    iwait = nwait;
//             sleep(1);
    if(mode==1) iwait=nwait*100;
    if(mode==2) iwait=nwait*100;
    i =j=0;
    mm=strlen(m);
    for (n = 0; n < mm; n++)
    {
        outb (m[n], base);
        printf("%1c",m[n]);
        kk = 0;
        while ((inb (base + 5) & 32) != 32 && kk < nwait) kk++;         //transmitted
        kk = 0;
        while(kk < iwait)
        {
            while ((inb (base + 5) & 1) != 0 && i < 2048)      // bit0 data ready
            {
                chh = inb (base);
                if(n < mm - 1) kk=iwait;         // only expect echo char
                else
                {            // end of command
                    recvbuff[i] = chh;
                    i++;
                    if(mode==2 && chh == '\r')
                    {
                        i =0;
                        j =-1;
                        jj=sscanf(recvbuff,"%*s %*s %d %*s %x",&j,&amp);
                        if(j<nscope && j >=0 && jj==2)
                        {
                            pw[j]        =(amp>>16)<<16;
                            pw[j+nscope] = 1;       // mark data as recvbuffd
                            printf("%3d power %12d\n",j,pw[j]);
                        }
                    }
                    if(mode != 2 || n < mm - 1) printf("%1c",chh);
                }
            }
            kk++;
        }
    }
    printf("\n");
}

void err(const char *fmt, ...)
{
  fprintf(stderr, "%s\n", fmt);
  exit(1);
}

int udp_client(const char *host, const char *serv, void **saptr, socklen_t *lenp)
{
  int sockfd, n;
  struct addrinfo hints, *res, *ressave;

  bzero(&hints, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_DGRAM;

  if ( (n = getaddrinfo(host, serv, &hints, &res)) != 0)
    err("udp_client error for %s, %s: %s",
              host, serv, gai_strerror(n));
  ressave = res;

  do {
    sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (sockfd >= 0)
      break;          /* success */
  } while ( (res = res->ai_next) != NULL);

  if (res == NULL)        /* errno set from final socket() */
    err("udp_client error for %s, %s", host, serv);

  *saptr = malloc(res->ai_addrlen);
  memcpy(*saptr, res->ai_addr, res->ai_addrlen);
  *lenp = res->ai_addrlen;

  freeaddrinfo(ressave);

  return(sockfd);
}

